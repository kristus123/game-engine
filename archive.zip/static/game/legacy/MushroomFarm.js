export class MushroomFarm {
	constructor() {

		this.localObjects = new LocalObjects([

		])
	}
}
