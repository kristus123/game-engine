export const Cam = new Camera()
