export class MouseResize {
	constructor(objectToResize) {
	}

	update() {
		if (Mouse.down) {

		}
	}

	draw(draw, guiDraw) {
	}
}
