export class OnlineMouse {
	constructor() {
	}
}
