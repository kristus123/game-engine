export const G = {
	ranches: new LocalObjects([]),
	poop: new LocalObjects([]),
	monsters: new LocalObjects([]),
	splash: new SplashParticles(),
	money: 0,
}
