export class LocalObjects extends AllObjects {
	constructor(objects=[]) {
		super(objects)
	}
}
