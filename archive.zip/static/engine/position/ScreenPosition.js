export class ScreenPosition {
	constructor(position) {
	}

	get x() {
	}

	get y() {
	}

}
