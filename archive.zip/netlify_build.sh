#!/bin/bash

node build_tools/generate_dist.js
