export function NotArray(x) {
	return !Array.isArray(x)
}
