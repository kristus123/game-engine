export function AnArray(x) {
	return Array.isArray(x)
}
