export class StaticGameObject extends _GameObject {
	constructor(position) {
		super(position)
	}
}
