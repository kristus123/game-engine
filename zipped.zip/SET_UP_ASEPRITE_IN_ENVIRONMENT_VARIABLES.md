# Set up Aseprite to be used inside cmd for Windows

win + search
"environment variable"
(Edit the system environment variables)

## click here

<img width="439" height="511" alt="image" src="https://github.com/user-attachments/assets/4ad9e9da-b169-4e94-91c5-ef40221f3337" />

## open this

<img width="632" height="599" alt="image" src="https://github.com/user-attachments/assets/f3d1c8e6-b4bf-4fd2-a1f5-0ad6b5371c67" />

## click here

<img width="548" height="538" alt="image" src="https://github.com/user-attachments/assets/65fcb41a-0fae-4228-b12f-4fdb2a3a81f7" />

## add the path to where aseprite.exe is 

if built from source:

```
C:\aseprite\build\bin
```

if you using steam:

```
todo truc-my give me your path
```


# FINISHED


then refresh your cmd by running this:

```
set PATH=%PATH%
```

or by restarting cmd.
