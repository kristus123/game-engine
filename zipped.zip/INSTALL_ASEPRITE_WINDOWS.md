# Install Aseprite
[check the newest version](https://github.com/aseprite/aseprite/releases)


[download newest version of aseprite](https://github.com/aseprite/aseprite/releases/download/v1.3.14.2/Aseprite-v1.3.14.4-Source.zip)
create C:\aseprite


[install latest version of cmake3](https://cmake.org/files/v3.31/cmake-3.31.8-windows-x86_64.msi)

aseprite currently recommends cmake3


download ninja
[latest version as of now](https://github.com/ninja-build/ninja/releases/tag/v1.13.1)
create C:\ninja



download skia

[skia](https://github.com/aseprite/skia/releases/download/m124-08a5439a6b/Skia-Windows-Release-x64.zip)
create C:\deps
